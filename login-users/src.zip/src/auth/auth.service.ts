import {
  Inject,
  Injectable,
  UnauthorizedException,
  OnModuleInit,
} from '@nestjs/common';
import * as bcryptjs from 'bcryptjs';
import { LoginDto } from './dto/login.dto';
import { JwtService } from '@nestjs/jwt';
import { KafkaServices } from './kafka/kafka-constants';
import { ClientKafka } from '@nestjs/microservices';
import { KafkaTopics } from './kafka/kafka-topics.enum';
import { firstValueFrom, TimeoutError } from 'rxjs';
import { timeout } from 'rxjs/operators';

interface UserWithPassword {
  id: number;
  name: string;
  email: string;
  password: string;
  role: string;
}

@Injectable()
export class AuthService implements OnModuleInit {
  private readonly RPC_TIMEOUT = 5000;

  constructor(
    @Inject(KafkaServices.USER_LOGIN_SERVICE)
    private readonly kafkaClient: ClientKafka,
    private readonly jwtService: JwtService,
  ) {}

  async onModuleInit() {
    this.kafkaClient.subscribeToResponseOf(
      KafkaTopics.GET_USER_BY_EMAIL_WITH_PASSWORD,
    );
    await this.kafkaClient.connect();
  }

  async login({ email, password }: LoginDto) {
    let user: UserWithPassword;

    try {
      user = await firstValueFrom(
        this.kafkaClient
          .send(KafkaTopics.GET_USER_BY_EMAIL_WITH_PASSWORD, { email })
          .pipe(timeout(this.RPC_TIMEOUT)),
      );
    } catch (error) {
      if (error instanceof TimeoutError) {
        throw new UnauthorizedException(
          'Tiempo de espera agotado al contactar al microservicio',
        );
      }
      throw new UnauthorizedException(
        'Error al obtener usuario: ' + error?.message,
      );
    }

    if (!user || !user.password) {
      throw new UnauthorizedException('Usuario no encontrado');
    }

    const isPasswordValid = await bcryptjs.compare(password, user.password);
    if (!isPasswordValid) {
      throw new UnauthorizedException('Contraseña incorrecta');
    }

    const payload = { email: user.email, role: user.role };
    const token = await this.jwtService.signAsync(payload);

    return {
      token,
      email: user.email,
    };
  }
}
