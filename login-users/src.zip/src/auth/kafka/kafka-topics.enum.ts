export enum KafkaTopics {
  LOGIN_USER = 'login-user',
  GET_USER_BY_EMAIL_WITH_PASSWORD = 'get-user-by-email-with-password',
}
