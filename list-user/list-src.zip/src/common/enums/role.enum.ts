export enum Role {
  USER = 'user', // Regular user role
  ADMIN = 'admin', // Admin role with elevated privileges
}
