export enum KafkaTopics {
  VERIFY_TOKEN = 'auth.verify-token',
}
