export const KafkaServices = {
  AUTH_VERIFIER_SERVICE: 'AUTH_VERIFIER_SERVICE',
};
