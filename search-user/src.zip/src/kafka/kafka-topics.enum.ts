export enum KafkaTopics {
  GET_USER_BY_ID = 'get-user-by-id',
  GET_USER_BY_EMAIL = 'get-user-by-email',
  GET_USER_BY_EMAIL_WITH_PASSWORD = 'get-user-by-email-with-password',
}
