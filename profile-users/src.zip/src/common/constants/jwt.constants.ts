export const jwtConstants = {
  secret: 'kalemat2025',
};
