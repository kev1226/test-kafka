export interface UserActiveInterface {
  email: string;
  role: string;
}
