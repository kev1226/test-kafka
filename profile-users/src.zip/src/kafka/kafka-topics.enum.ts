export enum KafkaTopics {
  PROFILE_USER = 'profile-user',
  GET_USER_BY_EMAIL = 'get-user-by-email',
}
